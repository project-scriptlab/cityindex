<p>An e-mail update was requested on <?= base_url() ?>!</p>

<p>If you didn't request this change, please contact us as soon as possible!</p>
